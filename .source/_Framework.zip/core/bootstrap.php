<?php
require 'core/helpers.php';
require 'core/Router.php';

// require 'app/Models/Example.php';