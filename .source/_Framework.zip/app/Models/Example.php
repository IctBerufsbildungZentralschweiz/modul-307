<?php
/**
 * Das Model "Example" implementiert alle grundlegenden Funktionen einer Datenbank-
 * Anwendung: load (SELECT), save (INSERT oder UPDATE) und delete (DELETE).
 */
class Example
{
	public int $id = 0;
	public string $name = '';

	/**
	 * create() initialisiert alle Eigenschaften des Objekts
	 * Für neue Datensätze kann die $id auf 0 gesetzt werden.
	 */
	public function create(int $id, string $name): ?self
	{
		$this->id = $id;
		$this->name = $name;
		return $this;
	}

	public function load(int $id): ?self
	{
		$statement = db()->prepare('SELECT * FROM example WHERE id = :id LIMIT 1');
		$statement->bindParam(':id', $id);
		$statement->execute();
		$result = $statement->fetch();

		if ($result) {
			// Datensatz gefunden? Eigenschaften setzen und Objekt zurückgeben.
			$this->id = $result['id'];
			$this->name = $result['name'];
			return $this;

		} else {
			// Datensatz NICHT gefunden? null zurückgeben.
			return null;
		}
	}

	public function save(): int
	{
		$db = db();

		if (!$this->id) {
			// Neuer Datensatz einfügen (INSERT)
			$statement = $db->prepare('INSERT INTO examples SET name = :name');

		} else {
			// Bestehender Datensatz aktualisieren (UPDATE)
			$statement = $db->prepare('UPDATE examples SET name = :name WHERE id = :id');
			$statement->bindParam(':id', $this->id);
		}

		// Binde alle übrigen Eigenschaften an das DB-Statement.
		$statement->bindParam(':name', $this->name);

		// Führe das DB-Statement aus.
		$statement->execute();

		// Neuer Datensatz? Setze die neue ID
		if (!$this->id) {
			$this->id = $db->lastInsertId();
		}

		// Gib die Anzahl der gespeicherten Datensätze zurück (1 = Erfolg, 0 = Fehler)
		return $statement->rowCount();
	}

	public function delete(): int
	{
		if ($this->id) {
			$statement = db()->prepare('DELETE FROM example WHERE id = :id');
			$statement->bindParam(':id', $this->id);
			$statement->execute();

			// Gib die Anzahl der gelöschten Datensätze zurück (1 = Erfolg, 0 = Fehler)
			return $statement->rowCount();
		} else {
			return 0;
		}
	}
}
