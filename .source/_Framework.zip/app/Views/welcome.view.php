<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Meine Seite</title>
    <base href="<?= dirname($_SERVER['SCRIPT_NAME']); /* relative urls start at index.php's directory */ ?>/" />
    <link rel="stylesheet" href="public/css/app.css">
</head>
<body>

<h1 class="welcome">Willkommen im 307-Framework!</h1>


<p><?= e($hello) ?></p>

<script src="public/js/app.js"></script>
</body>
</html>
