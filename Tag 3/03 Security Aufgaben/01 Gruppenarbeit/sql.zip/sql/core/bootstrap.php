<?php
require 'core/helpers.php';
require 'core/database.php';

require 'core/Router.php';
