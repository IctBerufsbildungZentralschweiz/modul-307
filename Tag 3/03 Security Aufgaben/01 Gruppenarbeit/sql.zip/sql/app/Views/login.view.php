<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Meine Seite</title>
    <link rel="stylesheet" href="public/css/app.css">
</head>
<body>

	<form action="login" method="POST">

		<div class="form-field">
			<label for="username">Username</label>
			<input type="text" id="username" name="username">
		</div>
		<div class="form-field">
			<label for="password">Passwort</label>
			<input type="password" id="password" name="password">
		</div>

		<input type="submit" value="Login">

	</form>


</body>
</html>