<?php
// Suche musst Du noch machen, KArl!
?>

<h1>Suchergebnisse</h1>

<p>Deine Suche nach "<?= $_GET['q'] ?? '' ?>" lieferte keine Treffer!</p>