<?php
require 'app/Views/welcome.view.php';